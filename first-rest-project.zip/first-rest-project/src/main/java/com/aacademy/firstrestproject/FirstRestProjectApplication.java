package com.aacademy.firstrestproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstRestProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstRestProjectApplication.class, args);
	}

}
